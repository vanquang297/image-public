
-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `currentNumber` int(11) DEFAULT NULL,
  `maxNumber` int(11) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `timeType` varchar(255) DEFAULT NULL,
  `doctorId` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `currentNumber`, `maxNumber`, `date`, `timeType`, `doctorId`, `createdAt`, `updatedAt`) VALUES
(1, NULL, 10, '1701968400000', 'T1', 14, '2023-12-07 08:14:41', '2023-12-07 08:14:41'),
(2, NULL, 10, '1701968400000', 'T2', 14, '2023-12-07 08:14:41', '2023-12-07 08:14:41'),
(3, NULL, 10, '1701968400000', 'T3', 14, '2023-12-07 08:14:41', '2023-12-07 08:14:41');
